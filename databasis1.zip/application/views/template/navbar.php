
</style></head>
<body>
<div class="container">
<style type="text/css">
<!--
.style3 {font-size: 36px}
-->
</style>
	<div class="row">
		<div class="col-md-12">
			<header>
				<p>&nbsp;</p>
				<p> <img src="FB_IMG_1587011139104.jpg" width="269" height="312" /><img src="FB_IMG_1587011139104.jpg" width="746" height="237" /></p>
				<p>	WIBSITE SEKOLAH MTS PONDOK PESANTREN DEMPO DARUL MUTAQIEN     			
			      </nav>
                      </p>
		  </header>
			<div class="navbar-header">
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
<button class="btn btn-style btn-pale">login</button>
<button class="btn btn-style btn-pale">Profil</button>
<button class="btn btn-style btn-pale">Alamat</button>
<button class="btn btn-style btn-pale">Visi & Misi</button>
<button class="btn btn-style btn-pale">Struktur Organisasi</button>
		  </div>

						<div id="navbar" class="navbar-collapse collapse">
							<ul class="nav navbar-nav">
								<li><a href="?page=home"><i class="glyphicon glyphicon-home"> login</i> </a></li>
								<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href=""><i class="glyphicon glyphicon-th"></i> Profile <span class='caret'></span></a>
									<ul class="dropdown-menu">
                                    <li><a href="?page=sejarah">Alamat</a></li>
										<li><a href="?page=visimisi">Visi & Misi</a></li>
										<li><a href="?page=struktur">Struktur Organisasi</a></li>
									</ul>
								</li>
                                
<li><a href="?page=galeri"><i class="glyphicon glyphicon-picture"></i>Galeri</a></li>
                                
							  <li class="dropdown"></li>
 
					
                                
                            
                                


								
						  </ul>
		  </div>
                        <span style="color:#000000"><em><span class="style3"></span>
                        <marquee bgcolor="#00FF66">
                        <strong>Website Sekolah Pondok Pesantren Dempo Darul Mutaqien</strong>
                        </marquee>
                        </em><span style="color:#000000">
          </nav>
