<!DOCTYPE html>
<html>
<head>
	<title>Artikel</title>
</head>
<body>
	<h1>Judul Artikel</h1>
	<p>Isi dari artikel</p>
	
</body>
</html> 
  